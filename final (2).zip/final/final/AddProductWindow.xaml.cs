﻿using final.Models;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace final;

/// <summary>
/// Interaction logic for AddProductWindow.xaml
/// </summary>
public partial class AddProductWindow : Window
{
    public Product NewProduct { get; set; }

    public AddProductWindow()
    {
        InitializeComponent();
        NewProduct = new Product();
    }

    private void SelectImage_Click(object sender, RoutedEventArgs e)
    {
        OpenFileDialog openFileDialog = new OpenFileDialog();
        openFileDialog.Filter = "Image Files|*.png;*.jpg;*.jpeg;*.gif;*.bmp|All Files|*.*";

        if (openFileDialog.ShowDialog() == true)
        {
            NewProduct.Photo = new BitmapImage(new Uri(openFileDialog.FileName));

            productImage.Source = NewProduct.Photo;
        }
    }

    private void OkButton_Click(object sender, RoutedEventArgs e)
    {
        NewProduct.Name = productNameTextBox.Text;

        if (double.TryParse(priceTextBox.Text, out double parsedPrice))
        {
            NewProduct.Price = parsedPrice;
            DialogResult = true;
        }
        else
        {
            MessageBox.Show("Please enter a valid number.");
        }
    }
}
