﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace final.Models
{
    public class Admin
    {
        public string Pass { get; set; } = "1234admin";
    }
}
