﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace final.Models;
public class User : NotificationChanged
{
    private static int nextID = 0;
    public int id;
    public string name = ""; 
    public string email= "";
    public string password ="";
    public int totalprice = 0;
    public List<Product> products=new List<Product>();

    public User()
    {
        id = ++nextID;
    }

    public int Id
    {
        get { return id; }
        set
        {
            id = value;
            OnPropertyChanged(nameof(Id));
        }
    }

    public string Name
    {
        get { return name; }
        set
        {
            name = value;
            OnPropertyChanged(nameof(Name));
        }
    }
    public string Email
    {
        get { return email; }
        set 
        {
            email = value;
            OnPropertyChanged(nameof(Email));
        }
    }
    public string Password
    {
        get { return password; }
        set
        {
            password = value;
            OnPropertyChanged(nameof(Password));
        }
    }
    public List<Product> BasketProductList
    {
        get { return products; }
        set
        {
            products = value;
            OnPropertyChanged(nameof(BasketProductList));
        }

    }
    public int TotalPrice 
    {
        get { return totalprice; }
        set
        {
            totalprice = value;
            OnPropertyChanged(nameof(TotalPrice));
        }
    }
}