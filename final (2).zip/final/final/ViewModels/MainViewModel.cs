﻿using System.Collections.ObjectModel;
using System.Windows.Input;
using final.Commands;
using final.Models;
using final.Services;

namespace final.ViewModels;

public class MainViewModel : ViewModelBase
{
    private ObservableCollection<User> users= new();
    private ObservableCollection<Product> products=new();
    private User selectedUser = new();
    private Product selectedProduct = new();
    private readonly DatabaseService databaseService = new();

    public MainViewModel()
    {
        databaseService = new DatabaseService();
        LoadUsers();
        LoadProducts();

        AddUserCommand = new RelayCommand(AddUser);
        UpdateUserCommand = new RelayCommand(UpdateUser, CanUpdateUser);
        DeleteUserCommand = new RelayCommand(DeleteUser, CanDeleteUser);

        AddProductCommand = new RelayCommand(AddProduct);
        UpdateProductCommand = new RelayCommand(UpdateProduct, CanUpdateProduct);
        DeleteProductCommand = new RelayCommand(DeleteProduct, CanDeleteProduct);
    }

    public ObservableCollection<User> Users
    {
        get { return users; }
        set
        {
            users = value;
            OnPropertyChanged(nameof(Users));
        }
    }

    public User SelectedUser
    {
        get { return selectedUser; }
        set
        {
            selectedUser = value;
            OnPropertyChanged(nameof(SelectedUser));
            ((RelayCommand)UpdateUserCommand).RaiseCanExecuteChanged();
            ((RelayCommand)DeleteUserCommand).RaiseCanExecuteChanged();
        }
    }

    public ObservableCollection<Product> Products
    {
        get { return products; }
        set
        {
            products = value;
            OnPropertyChanged(nameof(Products));
        }
    }
    public Product SelectedProduct
    {
        get { return selectedProduct; }
        set
        {
            selectedProduct = value;
            OnPropertyChanged(nameof(SelectedProduct));
            ((RelayCommand)UpdateProductCommand).RaiseCanExecuteChanged();
            ((RelayCommand)DeleteProductCommand).RaiseCanExecuteChanged();
        }
    }

    public ICommand AddUserCommand { get; }
    public ICommand UpdateUserCommand { get; }
    public ICommand DeleteUserCommand { get; }

    public ICommand AddProductCommand { get; }
    public ICommand UpdateProductCommand { get; }
    public ICommand DeleteProductCommand { get; }

    #region users
    private void LoadUsers()
    {
        Users = new ObservableCollection<User>(databaseService.LoadUsers());
    }
    
    public void AddUser()
    {
        databaseService.AddUser(new User());
        LoadUsers(); 
    }


    private void UpdateUser()
    {
        databaseService.UpdateUser(SelectedUser);
        LoadUsers();
    }

    private bool CanUpdateUser()
    {
        return SelectedUser != null;
    }

    private void DeleteUser()
    {
        databaseService.DeleteUser(SelectedUser.Id);
        LoadUsers();
    }

    private bool CanDeleteUser()
    {
        return SelectedUser != null;
    }
    #endregion

    #region proudts
    private void LoadProducts()
    {
        Products = new ObservableCollection<Product>(databaseService.LoadProducts());
    }

    private void AddProduct()
    {
        databaseService.AddProduct(new Product());
        LoadProducts();
    }

    private void UpdateProduct()
    {
        databaseService.UpdateProduct(SelectedProduct);
        LoadProducts();
    }

    private bool CanUpdateProduct()
    {
        return SelectedProduct != null;
    }

    private void DeleteProduct()
    {
        databaseService.DeleteProduct(SelectedProduct.ProductId);
        LoadProducts();
    }

    private bool CanDeleteProduct()
    {
        return SelectedProduct != null;
    }
    #endregion
}
