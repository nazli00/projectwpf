﻿namespace final.ViewModels
{
    public class ViewModelBase : NotificationChanged
    {
    }
}
