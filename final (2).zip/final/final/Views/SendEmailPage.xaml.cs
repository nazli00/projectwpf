﻿using final.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace final
{
    /// <summary>
    /// Interaction logic for SendEmailPage.xaml
    /// </summary>
    public partial class SendEmailPage : Page
    {
        string verrificationcode = string.Empty;
        DatabaseService databaseService=new();
        public SendEmailPage(string codestring, DatabaseService d)
        {
            InitializeComponent();
            databaseService = d;
            verrificationcode = codestring;
        }

        private void Nextbtn(object sender, RoutedEventArgs e)
        {
            if (verrificationcode == code.Text) 
            {
                Main.Content= new MainPage(databaseService.products);
            }
        }
        private void Backbtn(object sender, RoutedEventArgs e)
        {
            Main.NavigationService.Navigate(new Uri("verification.xaml", UriKind.Relative));
        }
    }
}
